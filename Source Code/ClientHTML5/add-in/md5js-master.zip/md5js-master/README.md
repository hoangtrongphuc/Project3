md5js
=====

MD5 digest algorithm implemented in javascript. No dependencies. Implemented
using typed arrays.

Why?
----

Because of reasons. I wanted to work with typed arrays, and this seemed like a 
good idea to give them a try. Most of the code is almost a direct translation
from the pseudo code in the Wikipedia entry about MD5 (even the dumbest parts).  

No idea on the performance of the implementation (hint: it will most likely suck). 
If you ever compare it with other implementations, let me know.
